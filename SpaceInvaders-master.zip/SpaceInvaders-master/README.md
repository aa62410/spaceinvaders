Space Invaders 
=============

A clone of Space Invaders, but with rectangles.
